//@ui5-bundle geo/map/Component-preload.js
sap.ui.require.preload({
	"geo/map/Component.js":function(){sap.ui.define(["sap/ui/core/UIComponent","sap/ui/Device","geo/map/model/models"],function(e,t,i){"use strict";return e.extend("geo.map.Component",{metadata:{manifest:"json"},init:function(){e.prototype.init.apply(this,arguments);this.getRouter().initialize();this.setModel(i.createDeviceModel(),"device")}})});
},
	"geo/map/controller/BaseController.js":function(){sap.ui.define(["sap/ui/core/mvc/Controller","sap/ui/core/routing/History","sap/ui/core/UIComponent","geo/map/model/formatter"],function(e,t,o,n){"use strict";return e.extend("geo.map.controller.BaseController",{formatter:n,getModel:function(e){return this.getView().getModel(e)},setModel:function(e,t){return this.getView().setModel(e,t)},getResourceBundle:function(){return this.getOwnerComponent().getModel("i18n").getResourceBundle()},navTo:function(e,t,o){this.getRouter().navTo(e,t,o)},getRouter:function(){return o.getRouterFor(this)},onNavBack:function(){var e=t.getInstance().getPreviousHash();if(e!==undefined){window.history.back()}else{this.getRouter().navTo("appHome",{},true)}}})});
},
	"geo/map/controller/MainView.controller.js":function(){sap.ui.define(["sap/ui/core/mvc/Controller"],function(e){"use strict";return e.extend("geo.map.controller.MainView",{})});
},
	"geo/map/i18n/i18n.properties":'title=geo.map\nappTitle=geo.map\nappDescription=App Description\n',
	"geo/map/i18n/i18n_en.properties":'title=geo.map\nappTitle=geo.map\nappDescription=App Description\n',
	"geo/map/manifest.json":'{"_version":"1.12.0","sap.app":{"id":"geo.map","type":"application","i18n":"i18n/i18n.properties","applicationVersion":{"version":"1.0.0"},"title":"{{appTitle}}","description":"{{appDescription}}"},"sap.ui":{"technology":"UI5","icons":{"icon":"","favIcon":"","phone":"","phone@2":"","tablet":"","tablet@2":""},"deviceTypes":{"desktop":true,"tablet":true,"phone":true}},"sap.ui5":{"rootView":{"viewName":"geo.map.view.MainView","type":"XML","async":true,"id":"idAppControl"},"dependencies":{"minUI5Version":"1.60.0","libs":{"sap.ui.core":{},"sap.m":{},"sap.ui.layout":{}}},"contentDensities":{"compact":true,"cozy":true},"models":{"i18n":{"type":"sap.ui.model.resource.ResourceModel","settings":{"bundleName":"geo.map.i18n.i18n"}}},"resources":{"css":[{"uri":"css/style.css"}]},"routing":{"config":{"routerClass":"sap.m.routing.Router","viewType":"XML","viewPath":"geo.map.view","controlId":"idAppControl","controlAggregation":"pages","async":true},"routes":[{"name":"RouteMainView","pattern":"RouteMainView","target":["TargetMainView"]}],"targets":{"TargetMainView":{"viewType":"XML","viewLevel":1,"viewId":"idAppControl","viewName":"MainView"}}}}}',
	"geo/map/model/formatter.js":function(){sap.ui.define([],function(){"use strict";return{}});
},
	"geo/map/model/models.js":function(){sap.ui.define(["sap/ui/model/json/JSONModel","sap/ui/Device"],function(e,n){"use strict";return{createDeviceModel:function(){var i=new e(n);i.setDefaultBindingMode("OneWay");return i}}});
},
	"geo/map/view/MainView.view.xml":' <mvc:View controllerName="geo.map.controller.MainView"\n  displayBlock="true"\n  xmlns="sap.m"\n  xmlns:mvc="sap.ui.core.mvc"><App id="idAppControl" ><pages><Page title="{i18n>title}"><content></content></Page></pages></App></mvc:View>'
});
