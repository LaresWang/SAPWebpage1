sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/ui/core/postmessage/Bus",
  "sap/ui/model/json/JSONModel",
], function (Controller, Postmessage, JSONModel) {
  "use strict";

  return Controller.extend("component.navbar.controller.MainView", {
    showModalFlag: false,
    onInit: function () {
      // var titl = new JSONModel(card),
      console.log(location.href)
      this.getView().setModel(new JSONModel({
        pageTitle: this.getValue('title', location.search)
      }));
    },
    getValue: function (name, qs) {
      if (!name || !qs) {
        return '';
      }

      var str = `[?&]?${name}=([^&]*)?&?`;
      var reg = new RegExp(str);
      var ret = qs.match(reg);
      if (!ret || !ret[1]) {
        return '';
      }
      return decodeURIComponent(ret[1]);
    },
    notificationsPressed: function () {
      console.log(new Postmessage())
      console.log(window)
      let post = new Postmessage();
      post.publish({ data: 'show_modal', eventId: '______READY______', channelId: 'navbar' })
      window.parent.postMessage('hide_modal', '*')
    },
    nativePost: function () {
      console.log('native')
      let msg = !this.showModalFlag ? 'show_modal' : 'hide_modal';
      this.showModalFlag = !this.showModalFlag;
      window.parent.postMessage(msg, 'https://dynamicsuppliermanager.us10.hcs.cloud.sap/')
    },
    modalFun: function () {
      let msg = !this.showModalFlag ? 'show_modal' : 'hide_modal';
      this.showModalFlag = !this.showModalFlag;
      window.parent.postMessage(msg, '*')
    }
  });
});
