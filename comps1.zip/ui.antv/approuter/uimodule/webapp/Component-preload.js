//@ui5-bundle ui/antv/Component-preload.js
sap.ui.require.preload({
	"ui/antv/Component.js":function(){sap.ui.define(["sap/ui/core/UIComponent","sap/ui/Device","ui/antv/model/models"],function(e,t,i){"use strict";return e.extend("ui.antv.Component",{metadata:{manifest:"json"},init:function(){e.prototype.init.apply(this,arguments);this.getRouter().initialize();this.setModel(i.createDeviceModel(),"device")}})});
},
	"ui/antv/controller/BaseController.js":function(){sap.ui.define(["sap/ui/core/mvc/Controller","sap/ui/core/routing/History","sap/ui/core/UIComponent","ui/antv/model/formatter"],function(e,t,o,n){"use strict";return e.extend("ui.antv.controller.BaseController",{formatter:n,getModel:function(e){return this.getView().getModel(e)},setModel:function(e,t){return this.getView().setModel(e,t)},getResourceBundle:function(){return this.getOwnerComponent().getModel("i18n").getResourceBundle()},navTo:function(e,t,o){this.getRouter().navTo(e,t,o)},getRouter:function(){return o.getRouterFor(this)},onNavBack:function(){var e=t.getInstance().getPreviousHash();if(e!==undefined){window.history.back()}else{this.getRouter().navTo("appHome",{},true)}}})});
},
	"ui/antv/controller/MainView.controller.js":function(){sap.ui.define(["sap/ui/core/mvc/Controller"],function(e){"use strict";return e.extend("ui.antv.controller.MainView",{})});
},
	"ui/antv/i18n/i18n.properties":'title=ui.antv\nappTitle=ui.antv\nappDescription=App Description\n',
	"ui/antv/i18n/i18n_en.properties":'title=ui.antv\nappTitle=ui.antv\nappDescription=App Description\n',
	"ui/antv/manifest.json":'{"_version":"1.12.0","sap.app":{"id":"ui.antv","type":"application","i18n":"i18n/i18n.properties","applicationVersion":{"version":"1.0.0"},"title":"{{appTitle}}","description":"{{appDescription}}"},"sap.ui":{"technology":"UI5","icons":{"icon":"","favIcon":"","phone":"","phone@2":"","tablet":"","tablet@2":""},"deviceTypes":{"desktop":true,"tablet":true,"phone":true}},"sap.ui5":{"rootView":{"viewName":"ui.antv.view.MainView","type":"XML","async":true,"id":"idAppControl"},"dependencies":{"minUI5Version":"1.60.0","libs":{"sap.ui.core":{},"sap.m":{},"sap.ui.layout":{}}},"contentDensities":{"compact":true,"cozy":true},"models":{"i18n":{"type":"sap.ui.model.resource.ResourceModel","settings":{"bundleName":"ui.antv.i18n.i18n"}}},"resources":{"css":[{"uri":"css/style.css"}]},"routing":{"config":{"routerClass":"sap.m.routing.Router","viewType":"XML","viewPath":"ui.antv.view","controlId":"idAppControl","controlAggregation":"pages","async":true},"routes":[{"name":"RouteMainView","pattern":"RouteMainView","target":["TargetMainView"]}],"targets":{"TargetMainView":{"viewType":"XML","viewLevel":1,"viewId":"idAppControl","viewName":"MainView"}}}}}',
	"ui/antv/model/formatter.js":function(){sap.ui.define([],function(){"use strict";return{}});
},
	"ui/antv/model/models.js":function(){sap.ui.define(["sap/ui/model/json/JSONModel","sap/ui/Device"],function(e,n){"use strict";return{createDeviceModel:function(){var i=new e(n);i.setDefaultBindingMode("OneWay");return i}}});
},
	"ui/antv/view/MainView.view.xml":' <mvc:View controllerName="ui.antv.controller.MainView"\n  displayBlock="true"\n  xmlns="sap.m"\n  xmlns:mvc="sap.ui.core.mvc"><App id="idAppControl" ><pages><Page title="{i18n>title}"><content></content></Page></pages></App></mvc:View>'
});
